-- OKK Club Manager V3.1: sigurno brisanje sa revizijskom evidencijom.
-- Pokreni jednom u SQL Editor-u. Ne briše postojeće podatke.
BEGIN;

-- Prava potrebna za brisanje (RLS pravila admin_access ostaju aktivna).
GRANT DELETE ON public.igraci, public.utakmice,
  public.oprema, public.finansije, public.dugovanja, public.isplate
  TO authenticated;

-- Brisanja se beleže čak i kada je red trajno uklonjen.
CREATE TABLE IF NOT EXISTS public.istorija_brisanja (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 tabela text NOT NULL,
 podaci jsonb NOT NULL,
 obrisao uuid,
 vreme timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.istorija_brisanja ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.istorija_brisanja FROM anon, authenticated;
GRANT SELECT ON public.istorija_brisanja TO authenticated;
DO $$
DECLARE p text;
BEGIN
 SELECT qual INTO p FROM pg_policies
 WHERE schemaname='public' AND tablename='finansije'
   AND policyname='admin_access';
 IF p IS NULL THEN
   RAISE EXCEPTION 'Nedostaje admin_access politika u tabeli finansije';
 END IF;
 EXECUTE 'DROP POLICY IF EXISTS admin_read_audit ON public.istorija_brisanja';
 EXECUTE format('CREATE POLICY admin_read_audit ON public.istorija_brisanja FOR SELECT TO authenticated USING (%s)',p);
END $$;

CREATE OR REPLACE FUNCTION public.okk_log_brisanje()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
 INSERT INTO public.istorija_brisanja(tabela,podaci,obrisao)
 VALUES (TG_TABLE_NAME,to_jsonb(OLD),auth.uid());
 RETURN OLD;
END $$;
REVOKE ALL ON FUNCTION public.okk_log_brisanje() FROM PUBLIC;
DO $$
DECLARE t text;
BEGIN
 FOREACH t IN ARRAY ARRAY['igraci','utakmice','oprema','finansije','dugovanja','isplate'] LOOP
  EXECUTE format('DROP TRIGGER IF EXISTS okk_audit_delete ON public.%I',t);
  EXECUTE format('CREATE TRIGGER okk_audit_delete BEFORE DELETE ON public.%I FOR EACH ROW EXECUTE FUNCTION public.okk_log_brisanje()',t);
 END LOOP;
END $$;

-- Ispravka postojeće funkcije: novo ubačena isplata se ne računa dvaput.
CREATE OR REPLACE FUNCTION public.proveri_isplatu_i_proknjizi()
RETURNS trigger LANGUAGE plpgsql SECURITY INVOKER
SET search_path=public, pg_temp AS $$
DECLARE dug numeric(14,2); ukupno numeric(14,2);
BEGIN
 SELECT pocetni_dug INTO dug FROM public.dugovanja
 WHERE id=NEW.dugovanje_id FOR UPDATE;
 IF dug IS NULL THEN RAISE EXCEPTION 'Dugovanje nije dostupno'; END IF;
 SELECT COALESCE(SUM(iznos),0) INTO ukupno FROM public.isplate
 WHERE dugovanje_id=NEW.dugovanje_id AND id <> NEW.id;
 IF ukupno+NEW.iznos>dug THEN
  RAISE EXCEPTION 'Isplata prelazi preostali dug';
 END IF;
 INSERT INTO public.finansije(datum,opis,vrsta,iznos,napomena,isplata_id)
 VALUES (NEW.datum,'Isplata duga #'||NEW.dugovanje_id,
 'rashod',NEW.iznos,'Automatski iz modula Dugovanja. '||COALESCE(NEW.napomena,''),NEW.id);
 RETURN NEW;
END $$;

-- Brisanje jedne isplate i automatski povezanog rashoda u istoj transakciji.
CREATE OR REPLACE FUNCTION public.okk_obrisi_isplatu(p_id bigint)
RETURNS boolean LANGUAGE plpgsql SECURITY INVOKER
SET search_path=public, pg_temp AS $$
DECLARE n bigint;
BEGIN
 -- Ako nije dozvoljeno čitanje isplate, nema brisanja.
 IF NOT EXISTS(SELECT 1 FROM public.isplate WHERE id=p_id) THEN RETURN false; END IF;
 DELETE FROM public.finansije WHERE isplata_id=p_id;
 DELETE FROM public.isplate WHERE id=p_id RETURNING id INTO n;
 RETURN n IS NOT NULL;
END $$;

-- Brisanje celog duga, njegovih isplata i pripadajućih rashoda.
CREATE OR REPLACE FUNCTION public.okk_obrisi_dugovanje(p_id bigint)
RETURNS boolean LANGUAGE plpgsql SECURITY INVOKER
SET search_path=public, pg_temp AS $$
DECLARE n bigint;
BEGIN
 IF NOT EXISTS(SELECT 1 FROM public.dugovanja WHERE id=p_id) THEN RETURN false; END IF;
 DELETE FROM public.finansije WHERE isplata_id IN
  (SELECT id FROM public.isplate WHERE dugovanje_id=p_id);
 DELETE FROM public.isplate WHERE dugovanje_id=p_id;
 DELETE FROM public.dugovanja WHERE id=p_id RETURNING id INTO n;
 RETURN n IS NOT NULL;
END $$;
REVOKE ALL ON FUNCTION public.okk_obrisi_isplatu(bigint),public.okk_obrisi_dugovanje(bigint) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.okk_obrisi_isplatu(bigint),public.okk_obrisi_dugovanje(bigint) TO authenticated;
COMMIT;
